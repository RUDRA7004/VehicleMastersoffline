Vehicle Masters Offline - Full Project (ready to upload)
=======================================================

What's inside:
- Assets/Scripts/  (all gameplay scripts tuned to your values)
- Assets/Scenes/Main.unity  (placeholder - see instructions)
- ProjectSettings/  (basic placeholders; set target API 33 in Cloud Build)
- CloudBuildGuide.txt  (step-by-step guide to build APK from phone)

Important:
- This archive is intended to be uploaded to Unity Cloud Build or opened in Unity Editor 2022.3 LTS.
- It targets Android 13+ (API level 33). Ensure cloud build target is set to API 33.
- You still need to open the project once in Unity to create the scene (or do so in Cloud Build if upload includes scene files).
- I can guide you through each upload step from your phone if you want.

Good luck and message me when you're ready for the next step!
