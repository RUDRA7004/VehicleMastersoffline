using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class SimpleCarController : MonoBehaviour
{
    [Header("Tuning (locked for your request)")]
    public float maxForwardSpeed = 50f;
    public float acceleration = 13f;
    public float brakeForce = 35f;
    public float turnSpeed = 60f;
    public Vector3 centerOfMass = new Vector3(0f, -0.6f, 0f);
    [Range(0.5f, 2f)] public float tireGrip = 1.15f; // 15% grip increase

    Rigidbody rb;

    // inputs set by MobileInput or keyboard
    [HideInInspector] public float inputVertical = 0f;   // -1..1
    [HideInInspector] public float inputHorizontal = 0f; // -1..1

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.centerOfMass = centerOfMass;
        rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
    }

    void Update()
    {
        // Optional keyboard fallback for quick testing in editor
        inputVertical = Input.GetAxis("Vertical");
        inputHorizontal = Input.GetAxis("Horizontal");
    }

    void FixedUpdate()
    {
        Vector3 forward = transform.forward;
        float currentFwdVel = Vector3.Dot(rb.velocity, forward);
        float desiredFwdVel = Mathf.Clamp(inputVertical, -1f, 1f) * maxForwardSpeed;

        // Acceleration / braking
        float speedDiff = desiredFwdVel - currentFwdVel;
        float accelForce = speedDiff * acceleration;
        rb.AddForce(forward * accelForce, ForceMode.Acceleration);

        // Additional braking (when pressing brake or reversing)
        if (inputVertical < -0.1f)
            rb.AddForce(-rb.velocity.normalized * brakeForce * Mathf.Abs(inputVertical), ForceMode.Acceleration);

        // Steering - less effective at high speeds for stability
        float speedFactor = Mathf.Clamp01(1f - (Mathf.Abs(currentFwdVel) / maxForwardSpeed));
        float turn = inputHorizontal * turnSpeed * speedFactor;
        Quaternion rot = Quaternion.Euler(0f, turn * Time.fixedDeltaTime, 0f);
        rb.MoveRotation(rb.rotation * rot);

        // Lateral stability: reduce sideways velocity (simulates tire grip)
        Vector3 lateralVel = Vector3.Project(rb.velocity, transform.right);
        rb.AddForce(-lateralVel * (tireGrip * 5f), ForceMode.VelocityChange);

        // Mild angular damping to avoid wild flips
        rb.angularVelocity = Vector3.Lerp(rb.angularVelocity, Vector3.zero, Time.fixedDeltaTime * 2f);
    }

    // public helpers for mobile UI to set inputs
    public void SetHorizontal(float h) { inputHorizontal = Mathf.Clamp(h, -1f, 1f); }
    public void SetVertical(float v) { inputVertical = Mathf.Clamp(v, -1f, 1f); }
    public void AddVertical(float delta) { inputVertical = Mathf.Clamp(inputVertical + delta, -1f, 1f); }
}
