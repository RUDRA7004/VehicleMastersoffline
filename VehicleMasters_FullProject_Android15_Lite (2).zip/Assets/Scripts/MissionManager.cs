using UnityEngine;

public class MissionManager : MonoBehaviour
{
    public Transform[] missionPoints;
    public float triggerRadius = 5f;
    public SimpleCarController playerCar;
    int currentMission = 0;

    void Update()
    {
        if (missionPoints == null || missionPoints.Length == 0 || playerCar == null) return;
        Transform t = missionPoints[currentMission];
        float d = Vector3.Distance(playerCar.transform.position, t.position);
        if (d <= triggerRadius)
        {
            CompleteMission();
        }
    }

    void CompleteMission()
    {
        Debug.Log("Mission " + currentMission + " completed!");
        // Reward: add money to save
        var data = SaveManager.Load();
        data.money += 200f;
        SaveManager.Save(data);

        currentMission = (currentMission + 1) % missionPoints.Length;
    }
}
