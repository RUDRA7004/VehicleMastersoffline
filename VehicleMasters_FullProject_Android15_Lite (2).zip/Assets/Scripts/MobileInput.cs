using UnityEngine;

// Simple singleton to relay UI button presses to the car
public class MobileInput : MonoBehaviour
{
    public static MobileInput I;
    public SimpleCarController car;

    void Awake()
    {
        if (I == null) I = this; else Destroy(gameObject);
    }

    public void SetSteerLeft(bool down) { if (car != null) car.SetHorizontal(down ? -1f : 0f); }
    public void SetSteerRight(bool down) { if (car != null) car.SetHorizontal(down ? 1f : 0f); }
    public void SetThrottle(bool down) { if (car != null) car.SetVertical(down ? 1f : 0f); }
    public void SetBrake(bool down) { if (car != null) car.SetVertical(down ? -1f : 0f); }
}
