using UnityEngine;
using UnityEngine.EventSystems;

// UI hooks for Button OnPointerDown / OnPointerUp events
public class UIController : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public enum ButtonType { Left, Right, Throttle, Brake }
    public ButtonType type;

    public void OnPointerDown(PointerEventData eventData)
    {
        if (MobileInput.I == null) return;
        switch (type)
        {
            case ButtonType.Left: MobileInput.I.SetSteerLeft(true); break;
            case ButtonType.Right: MobileInput.I.SetSteerRight(true); break;
            case ButtonType.Throttle: MobileInput.I.SetThrottle(true); break;
            case ButtonType.Brake: MobileInput.I.SetBrake(true); break;
        }
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (MobileInput.I == null) return;
        switch (type)
        {
            case ButtonType.Left: MobileInput.I.SetSteerLeft(false); break;
            case ButtonType.Right: MobileInput.I.SetSteerRight(false); break;
            case ButtonType.Throttle: MobileInput.I.SetThrottle(false); break;
            case ButtonType.Brake: MobileInput.I.SetBrake(false); break;
        }
    }
}
