using UnityEngine;
using System.IO;

[System.Serializable]
public class VehicleUpgrade { public int vehicleIndex; public int level; }

[System.Serializable]
public class PlayerData
{
    public int unlockedVehicleIndex = 0;
    public float money = 1000f;
    public VehicleUpgrade[] upgrades = new VehicleUpgrade[0];
}

public static class SaveManager
{
    static string fileName => PathCombine(Application.persistentDataPath, "save.json");

    static string PathCombine(string a, string b)
    {
        return System.IO.Path.Combine(a, b);
    }

    public static void Save(PlayerData data)
    {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(fileName, json);
        Debug.Log("Saved player data to: " + fileName);
    }

    public static PlayerData Load()
    {
        if (!File.Exists(fileName))
        {
            PlayerData d = new PlayerData();
            Save(d);
            return d;
        }
        string json = File.ReadAllText(fileName);
        return JsonUtility.FromJson<PlayerData>(json);
    }
}
